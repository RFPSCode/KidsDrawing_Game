/* =====================================================================
 * 拒毒萌芽小畫家｜雲端設定檔（只需要改這一個檔案）
 * 把 Apps Script「網頁應用程式」網址貼在下面兩個單引號中間，結尾必須是 /exec
 * 例：window.CLOUD_API_URL = 'https://script.google.com/macros/s/AKfy……/exec';
 * 留空 = 單機示範模式（資料只存在這台電腦的瀏覽器）
 * ===================================================================== */
window.CLOUD_API_URL = 'https://script.google.com/macros/s/AKfycbyhvCuCTEMjO22UHb3F8QR-3UaEgqFWZ5ntuK4jl8oDqJF0OK2r0ovCvelMfYdcdQ3OxA/exec';
